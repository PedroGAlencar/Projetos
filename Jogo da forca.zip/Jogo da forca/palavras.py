frutas = ['Abacaxi', 'Laranja', 'Goiaba', 'Morango', 'Maracuja', 'Melancia', 'Umbu', 'Tangerina', 'Mamao', 'Limao']

profissoes = ['Desenvolvedor', 'Jornalismo', 'Medico', 'Dentista', 'Professor', 'Engenharia', 'Entregador', 'Policial', 'Arquitetura', 'Psicologia']

comidas = ['Lasanha', 'Macarronada', 'Cozido', 'Feijoada', 'Pizza', 'Hamburguer', 'Churrasco', 'Escondidinho', 'Pastel', 'Coxinha']

esportes = ['Basquete', 'Futebol', 'Volei', 'Boxe', 'Surf', 'Atletismo', 'Handebol', 'Natação', 'Ginastica', 'Ciclismo']

objetos = ['Bola', 'Armario', 'Computador', 'Televisao', 'Cadeira', 'Estante', 'Mouse', 'Poltrona', 'Regua', 'Livro']